﻿using CommonComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Reflection;
using System.Threading;
using UDE_1._2_Regression.Main.pom.ude.pages;

namespace UDE_1._2_Regression.Test.pom.ude.tests
{
    [TestClass]
    public class UserManagementTest : BasePage
    {
        static LoginPage loginPage = new LoginPage(_driver);
        static UserManagementPage userManagementPage = new UserManagementPage(_driver);

        [TestMethod, TestCategory("User\\Group Managment")]
        public void TestMethod_01_New_User_Creation()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            foreach (var user in userManagementPage.NewUserCreation(Constants.Properties["role"], "Admin", rnd.Next(1, 5)))
            {
                loginPage.LoginUDE(user, Constants.Properties["newUserPswd"]);
                loginPage.LoginUDE(user, Constants.Properties["editNewUserPswd"]);
                Assertions.Contains(user.Replace(".", " "), userManagementPage.GetloggedUserName(), "Expected Name: " + user.Replace(".", " ") + "- Actual Name: " + userManagementPage.GetloggedUserName(), "Newly Created user verification", "Multiple User Creation", _driver);
                userManagementPage.LogOut();
            }
        }

        [TestMethod, TestCategory("User\\Group Managment")]
        public void TestMethod_02_User_Deletion()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            foreach (string user in userManagementPage.NewUserCreation(Constants.Properties["role"], "Admin", 1))
            {
                loginPage.LoginUDE(Constants.Properties["userid"], Constants.Properties["pswd"]);
                userManagementPage.UserDeletion(user);
                Assertions.Equals("User ID or Password is incorrect.", loginPage.ErrorMessage(user, Constants.Properties["newUserPswd"]), "Expected : User ID or Password is incorrect Message Displayed - True : Actual Expected : User ID or Password is incorrect Message Displayed - True", "UDE", "LOGIN", _driver);
            }
        }

        [TestMethod, TestCategory("User\\Group Managment")]
        public void TestMethod_03_User_Editing()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            foreach (string user in userManagementPage.NewUserCreation(Constants.Properties["role"], "Admin", 1))
            {
                loginPage.LoginUDE(user, Constants.Properties["newUserPswd"]);
                loginPage.LoginUDE(user, Constants.Properties["editNewUserPswd"]);
                userManagementPage.LogOut();
                loginPage.LoginUDE(Constants.Properties["userid"], Constants.Properties["pswd"]);
                userManagementPage.UserEditing(user);
                loginPage.LoginUDE(user, Constants.Properties["updateNewUserPswd"]);
                Assertions.Contains(user.Replace(".", " "), userManagementPage.GetloggedUserName(), "Expected Name: " + user.Replace(".", " ") + "- Actual Name: " + userManagementPage.GetloggedUserName(), "Newly Created user verification", "Multiple User Creation", _driver);
            }
        }

        [TestMethod, TestCategory("User\\Group Managment")]
        public void TestMethod_04_Group_Creation()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            foreach (string group in userManagementPage.GroupCreation("Admin", rnd.Next(1, 5)))
            {
                foreach (var user in userManagementPage.NewUserCreation(Constants.Properties["group"], group, rnd.Next(1, 5)))
                {
                    loginPage.LoginUDE(user, Constants.Properties["newUserPswd"]);
                    loginPage.LoginUDE(user, Constants.Properties["editNewUserPswd"]);
                    Assertions.Contains(user.Replace(".", " "), userManagementPage.GetloggedUserName(), "Expected Name: " + user.Replace(".", " ") + "- Actual Name: " + userManagementPage.GetloggedUserName(), "Newly Created user verification", "Multiple User Creation", _driver);
                    userManagementPage.LogOut();
                }
            }
        }

        [TestMethod, TestCategory("User\\Group Managment")]
        public void TestMethod_05_Group_Editing()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            foreach (string group in userManagementPage.GroupCreation("Admin", 1))
            {
                foreach (var user in userManagementPage.NewUserCreation(Constants.Properties["group"], group, 1))
                {
                    loginPage.LoginUDE(user, Constants.Properties["newUserPswd"]);
                    loginPage.LoginUDE(user, Constants.Properties["editNewUserPswd"]);
                    Assertions.Equals(true, userManagementPage.IsUserManagementTabPresent(), "Expected: " + "User Management is displayed" + "- Actual: " + userManagementPage.IsUserManagementTabPresent(), "User Management Tab is displayed for Group(s) with Admin Role", "User/Group Managment", _driver);
                    userManagementPage.GroupEditing(group, "Patrol Officer Role");
                    userManagementPage.LogOut();
                    loginPage.LoginUDE(user, Constants.Properties["editNewUserPswd"]);
                    Assertions.Equals(false, userManagementPage.IsUserManagementTabPresent(), "Expected: " + "User Management is NOT displayed" + "- Actual: " + userManagementPage.IsUserManagementTabPresent(), "User Management Tab is Not displayed for Group(s) with Officer Role", "User/Group Managment", _driver);
                }
            }
        }

        [TestMethod, TestCategory("User\\Group Managment")]
        public void TestMethod_06_Group_Deletion()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            foreach (string group in userManagementPage.GroupCreation("Admin", 1))
            {
                foreach (var user in userManagementPage.NewUserCreation(Constants.Properties["group"], group, 1))
                {
                    loginPage.LoginUDE(user, Constants.Properties["newUserPswd"]);
                    loginPage.LoginUDE(user, Constants.Properties["editNewUserPswd"]);
                    userManagementPage.GroupDelete(group);
                    userManagementPage.LogOut();
                    Assertions.Equals("No Role or Group Associated. Please contact Administrator", loginPage.ErrorMessage(user, Constants.Properties["editNewUserPswd"]), "Expected: " + "No Role or Group Associated. Please contact Administrator" + "- Actual: " + "No Role or Group Associated. Please contact Administrator", "UDE", "LOGIN", _driver);
                }
            }
        }


    }
}
