﻿using CommonComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using UDE_1._2_Regression.Main.pom.ude.pages;

namespace UDE_1._2_Regression.Test.pom.ude.tests
{
    [TestClass]
    public class SearchPageTest : BasePage
    {

        static SearchPage searchPage;
        static SystemPage systemPage;
        static UserManagementPage userManagementPage;

        [ClassInitialize]
        public static void Setup(TestContext context)
        {
            //loginPage = new LoginPage(_driver);
            //searchPage = loginPage.LoginUDE(Constants.Properties["userid"], Constants.Properties["pswd"]);
            systemPage = new SystemPage(_driver);
            userManagementPage = new UserManagementPage(_driver);
            searchPage = new SearchPage(_driver);
        }

        [TestMethod, TestCategory("Login")]
        public void TestMethod_01_LoginSuccessful()
        {
            try
            {
                Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
                Assertions.Equals(Constants.Properties["userid"] + " UDE", userManagementPage.GetloggedUserName(), "Expected : Log in Succesful for User " + Constants.Properties["userid"] + " UDE" + "- Actual : Log in Succesful for User " + userManagementPage.GetloggedUserName(), "UDE", "EvidenceSearchPage", _driver);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        [TestMethod, TestCategory("Evidence Search")]
        public void TestMethod_02_EvidenceSearch()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            List<string> files = DBConnection.RetrieveList("select top 1 filename from ContentFile where filename like 'UCJ%' and file_extension = 'mp4'", "filename");
            foreach (var item in files)
            {

                searchPage.SearchEvidence(item);
                Assertions.Contains(_driver.FindElement(By.XPath("//span[@id='evidenceName']")).GetAttribute("Title"), item, "Expected : " + _driver.FindElement(By.XPath("//span[@id='evidenceName']")).GetAttribute("Title") + "Search is succesfull - Actual : " + _driver.FindElement(By.XPath("//span[@id='evidenceName']")).GetAttribute("Title") + "Search is succesfull", "UDE", "Evidence Seacrh", _driver);
            }
        }

        //Fails because of the query 
        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_03_AdvanceSeacrh_Officer()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            searchPage.OfficerSeacrh(Constants.Properties["userid"]);
            Assertions.Equals(int.Parse(DBConnection.SelectColumnValue("select count(*) as ResultsCount from ContentSet where register_user_id in (Select user_id from staff where user_name ='" + Constants.Properties["userid"] + "') and is_converted_mp4_copied = 0")), int.Parse(searchPage.SearchResultsCount.Text), "Expected : Evidence Count by Officer - " + DBConnection.SelectColumnValue("select count(*) as ResultsCount from ContentSet where register_user_id in (Select user_id from staff where user_name = '" + Constants.Properties["userid"] + "') and is_converted_mp4_copied = 0") + " : Actual Evidence Count by Officer - " + int.Parse(searchPage.SearchResultsCount.Text).ToString(), "Advance Search", "Officer", _driver);
        }

        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_04_AdvanceSeacrh_With_Existing_MetaKey()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            var metakey = DBConnection.SelectColumnValue("select top 1 meta_key_name from MetaKey where is_active = 1 and meta_key_name in ('Agency','Area','Shift','Unit','Vehicle Id') order by NEWID()");
            var metakeyid = DBConnection.SelectColumnValue("select meta_key_id from MetaKey where meta_key_name = '" + metakey + "'");
            var metakeyvalue = DBConnection.Select("select top 1 [value] as Metavalue,count(*) as coun1 from contentmeta where meta_key_id ='" + metakeyid + "'  and [value] != '' group by [value] order by coun1 desc", "Metavalue");
            int evidencecount = int.Parse(DBConnection.SelectColumnValue("select count(*) as totalevidence from (select SUBSTRING(filename,0,25) as fileinfo,count(SUBSTRING(filename,0,25)) as cnt from ContentFile where content_set_id in "
            + "(select content_set_id from ContentMeta where [value] = '" + metakeyvalue + "' and meta_key_id = '" + metakeyid + "') "
            + "and file_extension in ('av3','mp4') and is_active = 1 and type != '' and split = 0 group by SUBSTRING(filename,0,25)) as t1"));
            searchPage.AdvSeacrh_Existing_MetaKey(metakey, metakeyvalue);
            Assertions.Equals(evidencecount, int.Parse(searchPage.SearchResultsCount.Text), metakey + "-Expected Evidence Count : " + int.Parse(searchPage.SearchResultsCount.Text).ToString() + "--" + metakey + "- Actual Evidence Count : " + evidencecount, "METAKEY Searched", metakey, _driver);
        }

        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_05_Multiple_MetaKey_Verification()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            searchPage.UpdatingMetaInfoDetails(systemPage.CreatingNewMetaKeys("Text", "Icv", rnd.Next(1, 5)));
            Assertions.Equals(int.Parse(searchPage.SearchResultsCount.Text), 1, "Expected Evidence Count: " + 1 + "- Actual Evidence Count : " + int.Parse(searchPage.SearchResultsCount.Text), "Evidence Search", "Multiple MetaKaeys", _driver);
        }

        [TestMethod, TestCategory("Advance Search")]
        [Ignore]
        public void TestMethod_06_AdvnaceSearch_ExpirationDate()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            searchPage.ExpirationDateSearch();
        }

        //[TestCleanup]
        //public void MyTestCleanup()
        //{
        //    try
        //    {
        //        if (TestContext.CurrentTestOutcome != UnitTestOutcome.Passed)
        //            Constants._testFailed = true;
        //        DBConnection.Delete("delete from MetaKey where meta_key_name like 'MetaKey2021%'");
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }
        //}

        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_07_AdvanceSeacrh_CreatedBy()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            searchPage.CreatedBy(Constants.Properties["userid"]);
            Assertions.Equals(int.Parse(DBConnection.SelectColumnValue("select count(*) as ResultsCount from ContentSet where register_user_id in (Select user_id from staff where user_name ='" + Constants.Properties["userid"] + "') and is_converted_mp4_copied = 0")), int.Parse(searchPage.SearchResultsCount.Text), "Expected : Evidence Count by Created By - " + DBConnection.SelectColumnValue("select count(*) as ResultsCount from ContentSet where register_user_id in (Select user_id from staff where user_name = '" + Constants.Properties["userid"] + "') and is_converted_mp4_copied = 0") + " : Actual Evidence Count by Created By - " + searchPage.SearchResultsCount.Text, "Advance Search", "Created By", _driver);
        }


        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_08_AdvanceSeacrh_Tag()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            var tag = DBConnection.Select("select tag, count(*) as tagcount from ContentSetTag group by tag having count(*) = (select max(count1) from (select Count(tag) as count1,tag from ContentSetTag  group by tag)tmp)", "tag");
            var tagcount = DBConnection.Select("select tag, count(*) as tagcount from ContentSetTag group by tag having count(*) = (select max(count1) from (select Count(tag) as count1,tag from ContentSetTag  group by tag)tmp)", "tagcount");
            searchPage.Tag(tag);
            Assertions.Equals(int.Parse(tagcount), int.Parse(searchPage.SearchResultsCount.Text), "Expected : Evidence Count by Tag - " + tagcount + " : Actual Evidence Count by Tag - " + searchPage.SearchResultsCount.Text, "Advance Search", "Tag", _driver);
        }



        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_07_AdvanceSeacrh_Verification_Yes()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            var Yes = DBConnection.SelectColumnValue("select count(*) as YCount From contentset where is_verified = 'Y' and is_converted_mp4_copied = 0 and duration > 0");
            searchPage.Verify_Y();
            Assertions.Equals(int.Parse(Yes), int.Parse(searchPage.SearchResultsCount.Text), "Expected : Evidence Count by Verfication Status  Yes - " + Yes + " : Actual Evidence Count by Verfication Status  Yes - " + searchPage.SearchResultsCount.Text, "Advance Search", "Tag", _driver);
        }


        [TestMethod, TestCategory("Advance Search")]
        public void TestMethod_07_AdvanceSeacrh_Verification_No()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            var No = DBConnection.SelectColumnValue("select count(*) as YCount From contentset where is_verified = 'N' and is_converted_mp4_copied = 0 and duration > 0");
            searchPage.Verify_N();
            Assertions.Equals(int.Parse(No), int.Parse(searchPage.SearchResultsCount.Text), "Expected : Evidence Count by Verfication Status  No - " + No + " : Actual Evidence Count by Verfication Status  No - " + searchPage.SearchResultsCount.Text, "Advance Search", "Tag", _driver);
        }
    }
}
