﻿using CommonComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UDE_1._2_Regression.Main.pom.ude.pages;

namespace UDE_1._2_Regression.Test.pom.ude.tests
{
    [TestClass]
    public class LoginPageTest : BasePage

    {

        LoginPage loginPage = new LoginPage(_driver);
        static SearchPage searchPage;
        UserManagementPage userManagementPage = new UserManagementPage(_driver);


        //[TestInitialize]
        //public static void Setup()
        //{
        //    loginPage = new LoginPage(_driver);
        //    searchPage = loginPage.LoginUDE(Constants.Properties["userid"], Constants.Properties["pswd"]);
        //}


        [TestMethod, TestCategory("Login")]

        public void TestMethod_00_VerifyLoginUnSuccesfull()
        {
            Assertions.CreateTest(string.Join(" ", MethodBase.GetCurrentMethod().Name.ToString().Split('_').Skip(2)), "Automated Tests");
            userManagementPage.LogOut();
            Wait.DefaultWait(10);
            var login = new Dictionary<string, string>(){
                        {"arbitrator", "abcdef"},
                        {"arbitrator1", "Test@12345"},
                        {"ABCDED", ""}};

            foreach (var item in login)
            {
                var errmessage = loginPage.ErrorMessage(item.Key, item.Value);
                Assertions.Equals("User ID or Password is incorrect", errmessage, "Expected : User ID or Password is incorrect Message Displayed - True : Actual Expected : User ID or Password is incorrect Message Displayed - " + errmessage, "UDE", "LOGIN", _driver);
            }

        }


        //[TestCleanup]
        //public void MyTestCleanup()
        //{
        //    try
        //    {
        //        if (TestContext.CurrentTestOutcome != UnitTestOutcome.Passed)
        //            Constants._testFailed = true;
        //        userManagementPage.LogOut();
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }


        //}


    }

}

