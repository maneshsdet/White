﻿using CommonComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using UDE_1._2_Regression.Main.pom.ude.pages;
using UDE_1._2_Regression.Test_Data.pom.ude.sqlqueries;

namespace UDE_1._2_Regression.Test.pom.ude.tests
{
    [TestClass]
    public class HelperScriptsTests : BasePage
    {

        static SearchPage searchPage;
        static LoginPage loginPage;
        //static SearchPageSQL searchPageSQL;

        [ClassInitialize]
        public static void Setup(TestContext context)
        {
            loginPage = new LoginPage(_driver);
            searchPage = loginPage.LoginUDE(Constants.Properties["userid"], Constants.Properties["pswd"]);
        }



        [TestMethod, Timeout(TestTimeout.Infinite), TestCategory("HelperScripts")]

        public void TestMethod_01_Seacrh_Playback()
        {
            try
            {
                Assertions.CreateTest("EvidenceSearch", "Automated Tests");
                List<string> files = DBConnection.RetrieveList("select eventId,duration From contentset where duration > 60 and duration < 120 and eventId is not null", "eventId");
                // DateTime runtime = DateTime.Now.AddDays(3);                
                //while (DateTime.Now < runtime)
                int i = 0;
                while (i < 1)
                {
                    foreach (var item in files)
                    {
                        try
                        {
                            searchPage.SearchEvidence(item);
                            searchPage.ClickEvidenceforPlayback(item, int.Parse(DBConnection.Select("select duration from contentset where eventId ='" + item + "'", "duration")));
                            //Assertions.Contains(_driver.FindElement(By.XPath("//span[@id='evidenceName']")).GetAttribute("Title"), item, "Expected : " + _driver.FindElement(By.XPath("//span[@id='evidenceName']")).GetAttribute("Title") + "Search is succesfull - Actual : " + _driver.FindElement(By.XPath("//span[@id='evidenceName']")).GetAttribute("Title") + "Search is succesfull", "UDE", "Evidence Seacrh", _driver);
                            Thread.Sleep(5000);
                            //searchPage.BackToEvidence();
                            //var element = _driver.FindElement(By.Id("btnEditEvidence"));
                            //element.SendKeys(Keys.LeftControl);
                            //element.Click();
                            Thread.Sleep(5000);
                            _driver.FindElementById("btnBackToEvidenceDetail").Click();

                        }
                        catch (Exception)
                        {
                            continue;
                        }

                    }
                    i++;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }


        [TestMethod, Timeout(TestTimeout.Infinite), TestCategory("HelperScripts")]
        [Ignore]
        public void Search_Status()
        {
            DateTime runtime = DateTime.Now.AddMinutes(1);
            while (DateTime.Now < runtime)
            {
                try
                {
                    searchPage.Status.Click();
                    Thread.Sleep(3000);
                    searchPage.File.Click();
                    Thread.Sleep(2000);
                    searchPage.Clear.Click();
                    searchPage.Search.Click();
                    Thread.Sleep(3000);
                }
                catch (Exception)
                {

                    continue;
                }
            }
        }

    }
}
