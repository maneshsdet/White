﻿using CommonComponents;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;

namespace UDE_1._2_Regression.Main.pom.ude.pages
{
    public class SystemPage : BasePage
    {
        public SystemPage(RemoteWebDriver driver) => _driver = driver;
        //Locator for System tab
        private IWebElement SystemTab => _driver.FindElement(By.Id("600"));
        //Locator for New button
        private IWebElement NewButton => _driver.FindElement(By.XPath("//button[contains(@class,'btn-block')][@id='btnCreateNew']"));
        //Locator for Meta Key Name
        private IWebElement MetaKeyNameInput => _driver.FindElement(By.Id("txtAttributeName"));
        //Locator for Meta Type field
        private IWebElement MetaTypeField => _driver.FindElement(By.Id("s2id_ddlDataType"));
        //Locator to Select Meta Type
        private IWebElement MetaType(String metaType)
        {
            return _driver.FindElement(By.XPath("//div[text()='" + metaType + "']"));
        }
        //Locator for Evidence Type field
        public IWebElement EvidenceTypeField => _driver.FindElement(By.Id("s2id_ddlAppliesTo"));
        //Locator for Display Message
        public IWebElement DisplayMessage => _driver.FindElement(By.Id("displaymessage"));
        //Locator to select Evidence Type
        private IWebElement EvidenceType(String evidenceType)
        {
            return _driver.FindElement(By.XPath("//div[text()='" + evidenceType + "']"));
        }
        //Locator for Save button
        private IWebElement SaveButton => _driver.FindElement(By.XPath("//button[contains(@class,'btn-block')][@id='btnSave']"));
        //Locator for Meta Key search input
        private IWebElement MetaKeySearch => _driver.FindElement(By.XPath("//div[@class='dataTables_scrollHead']//input"));
        //Locator for Searched Meta Key
        private IWebElement SearchedMetaKey(String text)
        {
            return _driver.FindElement(By.XPath("//td[text()='" + text + "']"));
        }
        //Locator for Cancel button
        private IWebElement CancelButton => _driver.FindElement(By.XPath("//button[contains(@class,'btn-block')][@id='btnCancel']"));
        //Locator for Delete button
        private IWebElement DeleteButton => _driver.FindElement(By.XPath("//button[contains(@class,'btn-block')][@id='btnConfirmDelete']"));
        //Locator for Modal dialog to delete MetaKey
        private IWebElement MetaKeyDeleteModal => _driver.FindElement(By.XPath("//div[@id='userheader']/.."));
        //Locator for OK button on Modal dialog to delete MetaKey
        private IWebElement OkDeleteMetaKey => _driver.FindElement(By.Id("btnConfirmWidgetOk"));

        public void ClickSystemTab()
        {
            Wait.WaitForElementDispalyed(_driver, By.Id("600"), 10);
            SystemTab.Click();
        }
        //public void CreatingNewMetaKey(String metaType, String evidenceType, int numOfMetaKeysToCreate)
        //{
        //    try
        //    {
        //        for (int i = 0; i < numOfMetaKeysToCreate; i++)
        //        {
        //            var timestamp = DateTimeStamp.getTimeStamp("yyyyMMddhmmsss");
        //            NewButton.Click();
        //            MetaKeyNameInput.SendKeys("MetaKey" + timestamp);
        //            MetaTypeField.Click();
        //            MetaType(metaType).Click();
        //            EvidenceTypeField.Click();
        //            EvidenceType(evidenceType).Click();
        //            SaveButton.Click();
        //            Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
        //        }

        //    }
        //    catch (Exception)
        //    {

        //        Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
        //    }

        //}
        public List<string> CreatingNewMetaKeys(string metaType, string evidenceType, int numOfMetaKeysToCreate)
        {
            try
            {
                ClickSystemTab();
                var MetaKeyList = new List<string>();
                for (int i = 0; i < numOfMetaKeysToCreate; i++)
                {
                    var timestamp = DateTimeStamp.getTimeStamp("yyyyMMddhmmsss");
                    NewButton.Click();
                    MetaKeyNameInput.SendKeys("MetaKey" + timestamp);
                    MetaTypeField.Click();
                    MetaType(metaType).Click();
                    EvidenceTypeField.Click();
                    EvidenceType(evidenceType).Click();
                    SaveButton.Click();
                    Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
                    MetaKeyList.Add("MetaKey" + timestamp);
                }

                return MetaKeyList;

            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return null;
            }
        }

        public void DeleteMetaKey(string metaKey, string metaKeyName)
        {
            try
            {
                MetaKeySearch.SendKeys(metaKey);
                SearchedMetaKey(metaKeyName).Click();
                DeleteButton.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnConfirmWidgetOk"), 10);
                OkDeleteMetaKey.Click();

            }
            catch (Exception)
            {

                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }

        }

    }

}
