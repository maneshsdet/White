﻿using CommonComponents;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using System.Reflection;
using System.Threading;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using System.Web;

namespace UDE_1._2_Regression.Main.pom.ude.pages
{

    public class UserManagementPage : BasePage
    {
        public static List<string> Grouplist = new List<string>();
        public static List<string> Userlist = new List<string>();
        public UserManagementPage(RemoteWebDriver driver) => _driver = driver;
        //Locator for User Management tab
        private IWebElement UserManagementTab => _driver.FindElement(By.Id("400"));
        //Locator for Create new UseName form
        private IWebElement CreateNewUserForm => _driver.FindElement(By.Id("Content"));
        //Locator for User ID
        private IWebElement UserIdInut => _driver.FindElement(By.Id("txtUserName"));
        //Locator for Password
        private IWebElement PasswordInput => _driver.FindElement(By.Id("txtPassword"));
        //Locator for Editing Password
        private IWebElement EditingPasswordInput => _driver.FindElement(By.Id("txtEditPassword"));
        //Locator for Confirm Password
        private IWebElement ConfirmPasswordInput => _driver.FindElement(By.Id("txtUserConfirmPassword"));
        //Locator for First Name
        private IWebElement FirstNameInput => _driver.FindElement(By.Id("txtFirstName"));
        //Locator for Last Name
        private IWebElement LastNameInput => _driver.FindElement(By.Id("txtFamilyName"));
        //Locator for Email ID
        private IWebElement EmailIdInput => _driver.FindElement(By.Id("txtEmailId"));
        //Locator for selecting Roles field
        private IWebElement SelectRolesField => _driver.FindElement(By.XPath("//label[text()='Select Roles']/..//input[contains(@id,'s2id_autogen')]"));
        //Locator for add Roles button
        private IWebElement AddRoles => _driver.FindElement(By.XPath("//button[@id='btnInstructionGroups']"));
        //Locator for Save button
        private IWebElement SaveButton => _driver.FindElement(By.XPath("//div[@id='dvFooter']//button[@id='btnSave']"));
        //Locator for UserName search input
        private IWebElement UserManagementSearch => _driver.FindElement(By.XPath("//div[@class='dataTables_scrollHead']//input"));
        //Locator for New button
        private IWebElement NewButton => _driver.FindElement(By.XPath("//button[@id='btnCreateNew'][contains(@class,'btn-block')]"));
        private IWebElement RolesDopDown => _driver.FindElement(By.XPath("//div[@class='select2-drop select2-drop-multi select2-display-none select2-drop-active']"));
        //Locator for user menu dropdown
        private IWebElement UserMenuDropdown => _driver.FindElement(By.Id("10000"));
        //Locator for Logout button
        private IWebElement Logout => _driver.FindElement(By.Id("logoff"));
        //Locator for UserName search input
        private IWebElement UserNameSearched => _driver.FindElement(By.XPath("//div[@class='dataTables_scrollHead']//input"));
        //Locator for Searched User name
        private IWebElement SearchedUserManagement(string text)
        {
            return _driver.FindElement(By.XPath("//td[contains(text(),'" + text + "')]"));
        }
        //Locator for Delete button
        private IWebElement DeleteButton(string id)
        {
            return _driver.FindElement(By.XPath("//button[contains(@class,'btn-block')][@id='" + id + "']"));
        }
        //Locator for OK button on Modal dialog to confirm the deletion
        private IWebElement OkDeleteButton => _driver.FindElement(By.Id("btnConfirmWidgetOk"));
        //Locator for Edit Password button
        private IWebElement EditPasswordButton => _driver.FindElement(By.Id("btnEditUserpassword"));
        //Locator for Group tab
        private IWebElement Group => _driver.FindElement(By.Id("402"));
        //Locator for Group Name input
        private IWebElement GroupNameInput => _driver.FindElement(By.Id("txtGroupName"));
        //Locator for add Roles button in Group tab
        private IWebElement GroupAddRoles => _driver.FindElement(By.XPath("//button[@id='btnRoles']"));
        //Locator for selecting Group field
        private IWebElement SelectGroupField => _driver.FindElement(By.XPath("//div[contains(@class,'form-group-multiselect')]//div[@id='s2id_ddlUserGroups']//input"));
        //Locator for add Group button
        private IWebElement AddGroup => _driver.FindElement(By.XPath("//button[@id='btnUserGroups']"));
        //Locator for Remove button
        private IWebElement Remove(string id)
        {
            return _driver.FindElement(By.XPath("//*[@id='" + id + "']//img[@id='imgDelete']"));
        }

        public List<string> NewUserCreation(string roleOrGroup, string roleTypeOrGroupName, int numOfUsersToCreate)
        {
            try
            {
                if (_driver.Url.Contains("Login"))
                {
                    new LoginPage(_driver).LoginUDE(Constants.Properties["userid"], Constants.Properties["pswd"]);
                }
                UserManagementTab.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnCreateNew"), 10);
                Userlist.Clear();
                for (int i = 0; i < numOfUsersToCreate; i++)
                {
                    var timestamp = DateTimeStamp.getTimeStamp("yyyyMMddhmmsss");
                    Console.WriteLine(timestamp);
                    NewButton.Click();
                    UserIdInut.SendKeys(Constants.Properties["prefix"] + timestamp);
                    PasswordInput.SendKeys(Constants.Properties["newUserPswd"]);
                    ConfirmPasswordInput.SendKeys(Constants.Properties["newUserPswd"]);
                    FirstNameInput.SendKeys(Constants.Properties["prefix"].TrimEnd('.'));
                    LastNameInput.SendKeys(timestamp);
                    EmailIdInput.SendKeys(Constants.Properties["prefix"] + timestamp + "@ude.com");
                    if (roleOrGroup.Equals(Constants.Properties["role"]))
                    {
                        SelectRolesField.SendKeys(roleTypeOrGroupName);
                        SelectRolesField.SendKeys(Keys.Enter);
                        SelectRolesField.SendKeys(Keys.Escape);
                        AddRoles.Click();
                    }
                    else if (roleOrGroup.Equals(Constants.Properties["group"]))
                    {
                        SelectGroupField.SendKeys(roleTypeOrGroupName);
                        SelectGroupField.SendKeys(Keys.Enter);
                        SelectGroupField.SendKeys(Keys.Escape);
                        AddGroup.Click();
                    }
                    SaveButton.Click();
                    Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
                    Userlist.Add(Constants.Properties["prefix"] + timestamp);
                }
                LogOut();
                return Userlist;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return null;
            }
        }

        public void UserDeletion(string user)
        {
            try
            {
                UserManagementTab.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnCreateNew"), 10);
                UserManagementSearch.SendKeys(user);
                Wait.WaitForElementDispalyed(_driver, By.XPath("//td[contains(text(),'" + user + "')]"), 10);
                SearchedUserManagement(user).Click();
                Wait.WaitForElementDispalyed(_driver, By.XPath("//button[contains(@class,'btn-block')][@id='btnUserConfirmDelete']"), 10);
                DeleteButton("btnUserConfirmDelete").Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnConfirmWidgetOk"), 10);
                OkDeleteButton.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
                LogOut();
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }

        public void UserEditing(string user)
        {
            try
            {
                UserManagementTab.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnCreateNew"), 10);
                UserManagementSearch.SendKeys(user);
                Wait.WaitForElementDispalyed(_driver, By.XPath("//td[contains(text(),'" + user + "')]"), 10);
                SearchedUserManagement(user).Click();
                Wait.WaitForElementDispalyed(_driver, By.XPath("//button[contains(@class,'btn-block')][@id='btnUserConfirmDelete']"), 10);
                EditPasswordButton.Click();
                EditingPasswordInput.SendKeys(Constants.Properties["updateNewUserPswd"]);
                ConfirmPasswordInput.SendKeys(Constants.Properties["updateNewUserPswd"]);
                SaveButton.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
                LogOut();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }

        public List<string> GroupCreation(string roleType, int numOfGroupToCreate)
        {
            try
            {
                UserManagementTab.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnCreateNew"), 10);
                for (int i = 0; i < numOfGroupToCreate; i++)
                {
                    var timestamp = DateTimeStamp.getTimeStamp("yyyyMMddhmmsss");
                    Group.Click();
                    NewButton.Click();
                    GroupNameInput.SendKeys(Constants.Properties["prefix"] + timestamp);
                    SelectRolesField.SendKeys(roleType);
                    SelectRolesField.SendKeys(Keys.Enter);
                    SelectRolesField.SendKeys(Keys.Escape);
                    GroupAddRoles.Click();
                    SaveButton.Click();
                    Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
                    Grouplist.Add(Constants.Properties["prefix"] + timestamp);
                }
                return Grouplist;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return null;
            }
        }

        public string GetloggedUserName()
        {
            try
            {
                return UserMenuDropdown.Text.Split(".")[0].Trim();
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return null;
            }
        }

        public void LogOut()
        {
            try
            {
                UserMenuDropdown.Click();
                Logout.Click();
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }

        public bool IsUserManagementTabPresent()
        {
            try
            {
                return _driver.FindElements(By.Id("400")).Count > 0;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return false;
            }
        }

        public void GroupEditing(string group, string roleType)
        {
            try
            {
                UserManagementTab.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnCreateNew"), 10);
                Group.Click();
                UserManagementSearch.SendKeys(group);
                Wait.WaitForElementDispalyed(_driver, By.XPath("//td[contains(text(),'" + group + "')]"), 10);
                SearchedUserManagement(group).Click();
                Wait.WaitForElementDispalyed(_driver, By.XPath("//div[@id='dvFooter']//button[@id='btnSave']"), 10);
                Remove("grdGroupRoles_wrapper").Click();
                SelectRolesField.SendKeys(roleType);
                SelectRolesField.SendKeys(Keys.Enter);
                SelectRolesField.SendKeys(Keys.Escape);
                GroupAddRoles.Click();
                SaveButton.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }

        public void GroupDelete(string group)
        {
            try
            {
                UserManagementTab.Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnCreateNew"), 10);
                Group.Click();
                UserManagementSearch.SendKeys(group);
                Wait.WaitForElementDispalyed(_driver, By.XPath("//td[contains(text(),'" + group + "')]"), 10);
                SearchedUserManagement(group).Click();
                Wait.WaitForElementDispalyed(_driver, By.XPath("//div[@id='dvFooter']//button[@id='btnSave']"), 10);
                DeleteButton("btnGroupConfirmDelete").Click();
                Wait.WaitForElementDispalyed(_driver, By.Id("btnConfirmWidgetOk"), 10);
                OkDeleteButton.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 10, "style", "display: none;");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }
    }
}
