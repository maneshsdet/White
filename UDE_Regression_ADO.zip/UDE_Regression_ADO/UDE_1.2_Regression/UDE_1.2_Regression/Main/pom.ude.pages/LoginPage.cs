﻿using CommonComponents;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using System;
using System.Reflection;
using System.Threading;

namespace UDE_1._2_Regression.Main.pom.ude.pages
{
    public class LoginPage : BasePage
    {

        public LoginPage(RemoteWebDriver driver) => _driver = driver;

        ////Locator for userid field
        //public IWebElement Username => _driver.FindElementById("txtLoginId");
        //// By UserId = By.Id("txtLoginId");

        ////Locator for password field        
        //public IWebElement Password => _driver.FindElementById("txtPassword");

        ////Locator for LoginButton field
        //public IWebElement LoginButton => _driver.FindElementById("btnLogin");
        //Locator for Change Pass
        private IWebElement ChangePass => _driver.FindElement(By.XPath("//div[contains(text(),'Change Password')]"));
        //Locator for Login
        private IWebElement Login => _driver.FindElement(By.XPath("//div[contains(text(),'Login')]"));
        //Locator for Old pass input
        private IWebElement OldPass => _driver.FindElement(By.Id("txtoldpassword"));
        //Locator for New pass input
        private IWebElement NewPass => _driver.FindElement(By.Id("txtnewpassword"));
        //Locator for Confirm New pass input
        private IWebElement ConfirmNewPass => _driver.FindElement(By.Id("txtConfirmPassword"));
        //Locator for Apply button
        private IWebElement ApplyBtn => _driver.FindElement(By.Id("btnApply"));
        //Locator For Error Message
        //private IWebElement ErrorMessga => _driver.FindElement(By.XPath("//div[normalize-space() = 'User ID or Password is incorrect.']"));
        public IWebElement ErrorMessga => _driver.FindElement(By.Id("displaymessage"));


        public SearchPage LoginUDE(string username, string password)
        {
            try
            {
                Username.Clear();
                Password.Clear();
                Username.SendKeys(username);
                Password.SendKeys(password);
                LoginButton.Click();
                _driver.Manage().Window.Maximize();
                Wait.DefaultWait(3);
                try
                {
                    if (ApplyBtn.Displayed)
                    {
                        OldPass.SendKeys(Constants.Properties["newUserPswd"]);
                        NewPass.SendKeys(Constants.Properties["editNewUserPswd"]);
                        ConfirmNewPass.SendKeys(Constants.Properties["editNewUserPswd"]);
                        ApplyBtn.Click();

                    }
                }
                catch (Exception)
                {

                    Console.WriteLine("ApplyBtn doesnt not exists");
                }
                return new SearchPage(_driver);
            }
            catch (System.Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return null;
            }
        }


        public string ErrorMessage(string username, string pswd)
        {
            try
            {
                Username.Clear();
                Password.Clear();
                Username.SendKeys(username);
                Password.SendKeys(pswd);
                LoginButton.Click();
                //Wait.WaitForElementAttribute(_driver, By.Id("displaymessage"), 3, "style", "display: flex;");
                Wait.DefaultWait(2);
                return ErrorMessga.Text;

            }
            catch (System.Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
                return null;

            }
        }


    }
}
