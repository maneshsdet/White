﻿using CommonComponents;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;

namespace UDE_1._2_Regression.Main.pom.ude.pages
{
    public class SearchPage : BasePage
    {

        public SearchPage(RemoteWebDriver driver) => _driver = driver;
        //Locator for Logoff field
        public IWebElement LogOff => _driver.FindElementById("logoff");
        //Locator for SearchByFileName
        public IWebElement SearchByFileName => _driver.FindElement(By.Id("txtFileName"));
        //Locator for ClearButton
        public IWebElement Clear => _driver.FindElement(By.Id("btnClear"));
        //Locator for Click
        public IWebElement Search => _driver.FindElement(By.Id("btnSearch"));
        //Locator for BackToEvidenceList
        public IWebElement BackToList => _driver.FindElement(By.Id("btnBackToEvidenceList"));
        //Locator for Adv Seach
        public IWebElement AdvSearch => _driver.FindElement(By.Id("slideAdvancedSearch"));
        //Locator for Officer
        public IWebElement Officer => _driver.FindElement(By.Id("s2id_autogen6"));
        public IWebElement Createdby => _driver.FindElement(By.Id("txtCreatedUserId"));
        //Tag
        public IWebElement TagSearch => _driver.FindElement(By.Id("txtSearchTag"));
        //Verify_Yes
        public IWebElement Yes => _driver.FindElement(By.Id("chkVerifiedYes"));
        //Verify_No
        public IWebElement No => _driver.FindElement(By.Id("chkVerifiedNo"));
        //Locator for SeacrhResultsCount
        public IWebElement SearchResultsCount => _driver.FindElement(By.Id("spnResultCount"));
        //Locator for Status
        public IWebElement Status => _driver.FindElement(By.LinkText("Status"));
        //Locator for File
        public IWebElement File => _driver.FindElement(By.LinkText("File"));
        //Locator for Add/Remove Meta Key
        public IWebElement AddRemoveMetaKey => _driver.FindElement(By.Id("addSearchMetaKey"));
        //Locator for Agency Meta key
        //public IWebElement AgencyMetaKey => _driver.FindElement(By.Id("ddlMetaKey")).FindElement(By.XPath(".//option[text()='Agency']"));
        //Locator for green arrow btton to add Meta key
        public IWebElement AddMetaKeysButton => _driver.FindElement(By.Id("addMetaKey"));
        //Locator for Ok button to save added Mea key
        public IWebElement AddingMetaKeysOKButton => _driver.FindElement(By.Id("confirmMetaKeySelect"));
        //Locator for Agency input field
        // public IWebElement MetaKeyAgencyField => _driver.FindElement(By.XPath("//label[text()='Agency']/..//input[@id='txtSelectMeta_1']"));
        //Locator for Evidence tab
        public IWebElement EvidenceTab => _driver.FindElement(By.Id("200"));
        //Locator for Evidence Type field
        public IWebElement EvidenceTypeField => _driver.FindElement(By.XPath("//div[@id='dvidMultipleEvidenceTypeContainer']//button"));
        //Locator to select checkbox from Evidence Type
        public IWebElement EvidenceCheckBox(string label) { return _driver.FindElement(By.XPath("//label[text()='" + label + "']")); }
        //Locator for Edit Evidence button
        private IWebElement EditEvidence => _driver.FindElement(By.Id("btnEditEvidence"));
        //Locator for Cancel button
        private IWebElement Cancel => _driver.FindElement(By.Id("btnBackToEvidenceDetail"));
        //Locator for Update button
        private IWebElement Update => _driver.FindElement(By.Id("btnapplymetadata"));
        //Locator for Expiration Date
        private IWebElement ExpDate => _driver.FindElement(By.Id("txtExpirationDates"));
        //Locators for Date Range
        private IWebElement DateRanges => _driver.FindElement(By.XPath("//div[@class='ranges']"));
        private IWebElement MetaKey(string metakey) { return _driver.FindElement(By.XPath("//label[text()='" + metakey + "']/..//input[@id='txtSelectMeta_1']")); }
        public IWebElement MetaKeySelect(string metakey) { return _driver.FindElement(By.Id("ddlMetaKey")).FindElement(By.XPath(".//option[text()='" + metakey + "']")); }
        //Locator for created Text Meta Key field inside of the Evidence Meta Info
        public IWebElement TextMetaKeyField(string label) { return _driver.FindElement(By.XPath("//label[text()='" + label + "']/..//input[contains(@id,'txtdynamicEditmeta')]")); }
        //Locator for created Text Meta Key field on Advance search slide
        public IWebElement AdvanceSearchMetaKey(string label) { return _driver.FindElement(By.XPath("//label[text()='" + label + "']/..//input[contains(@id,'txtSelectMeta')]")); }

        public void ClickEvidence(string evidencename)
        {
            try
            {
                if (evidencename.Contains("_"))
                {
                    _driver.FindElement(By.XPath("//label[contains(text(),'" + evidencename.Substring(0, 25) + "')]")).Click();
                    Wait.WaitForElementDispalyed(_driver, By.Id("evidenceName"), 10);
                }
                else
                {
                    _driver.FindElement(By.XPath("//label[contains(text(),'" + evidencename + "')]")).Click();
                    Wait.WaitForElementDispalyed(_driver, By.Id("evidenceName"), 10);
                }
                //    if (_driver.FindElement(By.XPath("//label[contains(text(),'" + evidencename.Substring(0, 25) + "')]")).Displayed)                
                //        { }
                //}
                //catch (Exception)
                //{
                //    File.AppendAllText("C:/Users/Manesh.Nallavalli/Desktop/FilesNotExists.txt", evidencename + Environment.NewLine);
                //}
                //Thread.Sleep(3000);
                //try
                //{
                //    if (_driver.FindElementById("btnmp4PlayVideo").Displayed)
                //    { _driver.FindElementById("btnmp4PlayVideo").Click(); }
                //}
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, "Search", _driver);
            }
            //Thread.Sleep(TimeSpan.FromSeconds(10));
            //_driver.FindElement(By.XPath("//div[contains(@title,'Play')]")).Click();
            // Thread.Sleep(TimeSpan.FromMinutes(40));
        }

        public void ClickEvidenceforPlayback(string evidencename, int timetowait)
        {

            try
            {
                if (evidencename.Contains("_"))
                {
                    _driver.FindElement(By.XPath("//label[contains(text(),'" + evidencename.Substring(0, 25) + "')]")).Click();
                    Wait.WaitForElementDispalyed(_driver, By.Id("evidenceName"), 10);
                }
                else
                {
                    _driver.FindElement(By.XPath("//label[contains(text(),'" + evidencename + "')]")).Click();
                    Wait.WaitForElementDispalyed(_driver, By.Id("evidenceName"), 10);
                }
                //    if (_driver.FindElement(By.XPath("//label[contains(text(),'" + evidencename.Substring(0, 25) + "')]")).Displayed)                
                //        { }
                //}
                //catch (Exception)
                //{
                //    File.AppendAllText("C:/Users/Manesh.Nallavalli/Desktop/FilesNotExists.txt", evidencename + Environment.NewLine);
                //}
                Thread.Sleep(3000);
                //try

                if (_driver.FindElementById("btnmp4PlayVideo").Displayed)
                { _driver.FindElementById("btnmp4PlayVideo").Click(); }

            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, "Search", _driver);
            }
            Thread.Sleep(TimeSpan.FromSeconds(10));
            _driver.FindElement(By.XPath("//div[contains(@title,'Play')]")).Click();
            Thread.Sleep(TimeSpan.FromMinutes(timetowait));
        }

        public void SearchEvidence(string evidencename)
        {
            try
            {
                Clear.Click();
                SearchByFileName.SendKeys(evidencename);
                Search.Click();
                Wait.WaitForElementClickable(_driver, By.Id("chkSearchEvidenceSelectAll"), 10);
                ClickEvidence(evidencename);
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, "Search", _driver);
            }
        }

        public void OfficerSeacrh(string officer)
        {
            try
            {
                Clear.Click();
                AdvSearch.Click();
                //Wait.WaitForElementAttributeContains(_driver, By.Id("filter-panel"), 20, "class", "; overflow-y: auto; display: block;");
                Wait.DefaultWait(5);
                Officer.SendKeys(officer);
                Officer.SendKeys(Keys.Enter);
                Search.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("dvSearchResults"), 10, "style", "display: block;");
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }

        }


        public void AdvSeacrh_Existing_MetaKey(string metakey, string value)
        {
            try
            {
                Clear.Click();
                AdvSearch.Click();
                Wait.WaitForElementClickable(_driver, By.Id("addSearchMetaKey"), 10);
                AddRemoveMetaKey.Click();
                MetaKeySelect(metakey).Click();
                AddMetaKeysButton.Click();
                Wait.WaitForElementClickable(_driver, By.Id("confirmMetaKeySelect"), 10);
                AddingMetaKeysOKButton.Click();
                Wait.DefaultWait(5);
                MetaKey(metakey).SendKeys(value);
                Search.Click();
                Wait.DefaultWait(5);
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }

        public void UpdatingMetaInfoDetails(List<string> MetakeysList)
        {
            try
            {
                EvidenceTab.Click();
                Clear.Click();
                var evidencename = DBConnection.SelectColumnValue("select Top 1 filename from contentfile where file_extension not in ('xml','jpg','jpeg') and type = 'v' and is_active = 1 order by upd_date desc");
                SearchByFileName.SendKeys(evidencename);
                Search.Click();
                Wait.WaitForElementClickable(_driver, By.Id("chkSearchEvidenceSelectAll"), 10);
                ClickEvidence(evidencename);
                Wait.WaitForElementClickable(_driver, By.Id("btnEditEvidence"), 10);//this wait fails in debug mode
                JavaScript.JsClick(_driver, EditEvidence);
                Wait.WaitForElementAttribute(_driver, By.Id("btnEditEvidence"), 10, "class", "btn btn-link  hidden");
                foreach (var item in MetakeysList)
                {
                    JavaScript.JsClick(_driver, TextMetaKeyField(item));
                    Wait.WaitForElementDispalyed(_driver, By.XPath("//label[text()='" + item + "']"), 10);
                    TextMetaKeyField(item).Clear();
                    TextMetaKeyField(item).SendKeys("UDEMETAKEY" + item.Substring(6));
                }
                Wait.DefaultWait(2);
                Update.Click();
                JavaScript.JsClick(_driver, BackToList);
                Clear.Click();
                Wait.DefaultWait(2);
                AdvSearch.Click();
                Wait.WaitForElementClickable(_driver, By.Id("addSearchMetaKey"), 10);
                AddRemoveMetaKey.Click();
                foreach (var item in MetakeysList)
                {
                    MetaKeySelect(item).Click();
                    AddMetaKeysButton.Click();
                }
                AddingMetaKeysOKButton.Click();
                foreach (var item in MetakeysList)
                {
                    AdvanceSearchMetaKey(item).SendKeys("UDEMETAKEY" + item.Substring(6));
                }
                Search.Click();
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }


        public void ExpirationDateSearch()
        {
            Clear.Click();
            AdvSearch.Click();
            Wait.DefaultWait(5);
            ExpDate.Click();
            Wait.DefaultWait(10);
            // _driver.FindElement(By.XPath("//div[@class='daterangepicker dropdown-menu ltr show-calendar opensright']/div[@class='ranges']/ul/li[contains(@text,'Last Hour')]")).Click();
            _driver.FindElement(By.XPath("//*[contains(@text(),'Last Hour')]")).Click();

            IList<IWebElement> links = DateRanges.FindElements(By.TagName("li"));

            foreach (var item in links)
            {
                Console.WriteLine(item.GetAttribute("data-range-key"));

                // _driver.FindElement(By.XPath("//div[@class='daterangepicker dropdown-menu ltr show-calendar opensright']/div[@class='ranges']/div[@class='range_inputs']/button[@class='applyBtn btn btn-sm btn-success']")).Click();
                //DateRanges.FindElement(By.TagName("li"));
                //   _driver.FindElementByLinkText("Last Hour").Click();
            }
        }


        public void CreatedBy(string createdby)
        {
            try
            {
                Clear.Click();
                AdvSearch.Click();
                Wait.DefaultWait(5);
                Createdby.SendKeys(createdby);
                Search.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("dvSearchResults"), 20, "style", "display: block;");
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }


        public void Tag(string tag)
        {
            try
            {
                Clear.Click();
                AdvSearch.Click();
                Wait.DefaultWait(5);
                TagSearch.SendKeys(tag);
                Search.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("dvSearchResults"), 10, "style", "display: block;");
            }
            catch (Exception)
            {

                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }


        public void Verify_Y()
        {
            try
            {
                Clear.Click();
                AdvSearch.Click();
                Wait.DefaultWait(5);
                Yes.Click();
                Search.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("dvSearchResults"), 10, "style", "display: block;");
            }
            catch (Exception)
            {

                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }

        public void Verify_N()
        {
            try
            {
                Clear.Click();
                AdvSearch.Click();
                Wait.DefaultWait(5);
                No.Click();
                Search.Click();
                Wait.WaitForElementAttribute(_driver, By.Id("dvSearchResults"), 10, "style", "display: block;");
            }
            catch (Exception)
            {
                Assertions.FailCase(MethodBase.GetCurrentMethod().Name, MethodBase.GetCurrentMethod().Name, _driver);
            }
        }
    }

}
