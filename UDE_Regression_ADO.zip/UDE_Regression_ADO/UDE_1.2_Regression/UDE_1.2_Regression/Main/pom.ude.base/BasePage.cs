using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using CommonComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.IO;
using System.Threading;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using UDE_1._2_Regression.Main.pom.ude.pages;
using UDE_1._2_Regression.Test_Data.pom.ude.sqlqueries;

namespace UDE_1._2_Regression
{
    [TestClass]
    public class BasePage
    {
        // public IWebDriver driver;

        public static RemoteWebDriver _driver;
        public static string ReportsDir;
        public Random rnd = new Random();


        //Locator for userid field
        public IWebElement Username => _driver.FindElementById("txtLoginId");
        // By UserId = By.Id("txtLoginId");

        //Locator for password field        
        public IWebElement Password => _driver.FindElementById("txtPassword");

        //Locator for LoginButton field
        public IWebElement LoginButton => _driver.FindElementById("btnLogin");
        public TestContext TestContext { get; set; }

        //public BasePage()
        //{
        //     LoginPage loginPage;
        //}

        [AssemblyInitialize]
        public static void Initilaize(TestContext context)
        {

            Constants.Properties = LoadProperties.GetProperties(Path.Combine(AppDomain.CurrentDomain.BaseDirectory.Split(new string[] { "bin" }, StringSplitOptions.None)[0], @"Main\pom.ude.config\config.properties"));
            ReportsDir = Directory.CreateDirectory(@"\\iproterastation\IPROFTP\FTPData\_PS_DevShare\ude-qa\2 - ReleaseForQA\12 - Automation\Reports\" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + @"\DEF").ToString();
            Constants.htmlReporter = new ExtentHtmlReporter(ReportsDir);
            Constants.extent.AttachReporter(Constants.htmlReporter);
            Constants.extent.AddSystemInfo("Host Name", "UDE 1.3");
            Constants.extent.AddSystemInfo("Environment", "UDEQA8");
            Constants.htmlReporter.LoadConfig(@"\\iproterastation\IPROFTP\FTPData\_PS_DevShare\ude-qa\2 - ReleaseForQA\12 - Automation\Automation Scripts\Config.xml");
            //ChromeOptions options = new ChromeOptions();
            //options.AddArgument("--allow-insecure-localhost");
            //options.AddArgument("--ignore-ssl-errors=yes");
            //options.AddArgument("--ignore-certificate-errors");
            //_driver = new ChromeDriver(options);
            //_driver.Url = Constants.Properties["url"];


        }

        [AssemblyCleanup]
        public static void Teardown()
        {
            DBConnection.Delete(DeleteQueries.DeleteUSers());
            _driver.Quit();
            Status logstatus;
            if (Constants._testFailed == false)
                logstatus = Status.Pass;
            else
                logstatus = Status.Fail;
            Constants.test.Log(logstatus, "Test execution ended with " + logstatus);
            Constants.extent.Flush();
            File.Move(ReportsDir.Split(new string[] { "DEF" }, StringSplitOptions.None)[0] + @"\index.html", ReportsDir.Split(new string[] { "DEF" }, StringSplitOptions.None)[0] + @"\UDE.html");
            Thread.Sleep(10000);
            var attachment = ReportsDir.Split(new string[] { "DEF" }, StringSplitOptions.None)[0] + @"\UDE.html";
            SendEmail.Email(Constants.Properties["sServerUserName"], Constants.Properties["sServerPswd"], Constants.Properties["sBody"], "Failure Count # " + Constants.Failure + " - " + Constants.Properties["sSubject"] + "-" + DateTime.Now.ToString("yyyy-MM-dd"), Constants.Properties["sFromAddress"], Constants.Properties["sToAddress"], attachment);
            Thread.Sleep(1000);
            Directory.Delete(ReportsDir);
        }

        [TestInitialize]

        public void Login()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--allow-insecure-localhost");
            options.AddArgument("--ignore-ssl-errors=yes");
            options.AddArgument("--ignore-certificate-errors");
            _driver = new ChromeDriver(options);
            _driver.Url = Constants.Properties["url"];
            Username.Clear();
            Password.Clear();
            Username.SendKeys(Constants.Properties["userid"]);
            Password.SendKeys(Constants.Properties["pswd"]);
            LoginButton.Click();
            _driver.Manage().Window.Maximize();
            Wait.DefaultWait(8);
        }

        [TestCleanup]
        public void MyTestCleanup()
        {
            try
            {
                if (TestContext.CurrentTestOutcome != UnitTestOutcome.Passed)
                    Constants._testFailed = true;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                _driver.Quit();
            }


        }
    }
}