﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UDE_1._2_Regression.Test_Data.pom.ude.sqlqueries
{
    class DeleteQueries
    {
    }
}
