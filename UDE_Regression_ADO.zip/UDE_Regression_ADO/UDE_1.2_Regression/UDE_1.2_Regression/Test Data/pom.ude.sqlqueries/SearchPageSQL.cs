﻿using CommonComponents;
using System;
using System.Collections.Generic;
using System.Text;

namespace UDE_1._2_Regression.Test_Data.pom.ude.sqlqueries
{
   public  static class SearchPageSQL
    {
      public static string[] abc()
        {
            return new[] { DBConnection.SelectColumnValue("select top 1 meta_key_name,meta_key_id from MetaKey where is_active = 1 and meta_key_name in ('Agency','Area','Shift','Unit','Vehicle Id') order by NEWID()") };           
        }

    }
}
